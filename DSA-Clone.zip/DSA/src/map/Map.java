package map;

import set.*;

/** A Map has Entries. Each Entry has a key
 * and a value. No Duplicate
 * @author sdb & Nicholas Sin */

public interface Map<K,V> {

    /** @return true iff this map has an entry with a key */
    boolean containsKey(K key);

    /** Search this Map for an Entry which has given key.
     * @return value of that entry, or null if not found */
    V get(K key);

    /** Search this Map for an Entry which has given key,
     * change its value to the given value. If not found
     * add new Entry to the map.
     * @return old value or null */
    V put(K key, V value);

    /** Remove the entry with a given key, from this map,
     * if possible.
     * @return its value, or null if not found */
    V remove(K key);

    /** @return the size of this Map */
    int size();

    /** @return true iff this Map is empty */
    boolean isEmpty();

    /** Clear this Map */
    void clear();
    
    /** @return a key for the given value, or null if not found */
    K getKey(V value);
    
    /** @return a Set of all the keys in this Map. */
    Set<K> keySet();
}
