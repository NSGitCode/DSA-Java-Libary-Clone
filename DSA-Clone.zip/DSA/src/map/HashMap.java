package map;

import hash.*;
import list.*;
import set.*;

/** A Map implemented with a HashTable of entries. Each Entry has a key
 * and a value.
 * @author sdb & Nicholas Sin */

public class HashMap<K,V> implements Map<K,V>{
    HashTable<Entry<K,V>> table = new  HashTable<Entry<K,V>>();

    class Entry<K,V>
    {
        K key;
        V value;

        //Constructor
        Entry(K key, V value)
        {
            this.key = key;
            this.value = value;
        }

        public boolean equals(Object obj)
        {
            Entry<K, V> other = (Entry) obj;
            return this.key.equals(other.key);
        }
        public int hashCode()
        {
            int code = 17;
            code = code*31+key.hashCode();
            return code;
        }
    } //End inner class

    public boolean containsKey(K key) {
       Entry<K,V> entry = new Entry<K,V>(key,null);
        return table.containsKey(entry);
    }

    public V get(K key) {
        Entry<K,V> entry = new Entry<K,V>(key,null);
        entry = table.get(entry);
        if(entry==null) return null;
        return entry.value;
    }

    public V put(K key, V value) {
        Entry<K,V> newEntry = new Entry<K,V>(key,value), oldEntry = table.get(newEntry);

        if(oldEntry == null)
        {
            table.put(newEntry);
            return null;
        }
        V result = oldEntry.value;
        oldEntry.value = value;
        return result;
    }

    public V remove(K key) {
        Entry<K,V> entry = new Entry<K,V>(key,null);
        entry = table.get(entry);
        if(entry == null)
            return null;
        table.remove(entry);
        return entry.value;
    }

    public int size() {
        return table.size();
    }

    public boolean isEmpty() {
        return table.isEmpty();
    }

    public void clear() {
        table.clear();
    }
    
    public K getKey(V value) {
        Iterator<HashMap<K, V>.Entry<K, V>> iterator = table.iterator();
        while (iterator.hasNext()) {
            Entry<K, V> entry = iterator.next();
            if (value.equals(entry.value)) {
                return entry.key;
            }
        }
        return null;
    }

    public Set<K> keySet() {
        Set<K> keys = new HashSet<K>();
        Iterator<Entry<K, V>> iterator = table.iterator();
        while (iterator.hasNext()) {
            Entry<K, V> entry = iterator.next();
            if (entry != null) {
                keys.add(entry.key);
            }
        }
        return keys;
    }
    
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
    }
        if (!(obj instanceof Map)) {
            return false;
        }
        Map<K, V> other = (Map<K, V>) obj;
        if (other.size() != size()) {
            return false;
        }
        Set<K> keys = keySet();
        Iterator<K> iterator = keys.iterator();
        while (iterator.hasNext()) {
            K key = iterator.next();
            V value = get(key);
            if (!other.containsKey(key) || !value.equals(other.get(key))) {
                return false;
            }
        }
        return true;
    }
    
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        boolean first = true;
        Iterator<Entry<K, V>> iterator = table.iterator();
        while (iterator.hasNext()) {
            Entry<K, V> entry = iterator.next();
            if (entry != null) {
                if (!first) {
                    sb.append(", ");
                }
                sb.append(entry.key).append("=").append(entry.value);
                first = false;
            }
        }
        sb.append("]");
        return sb.toString();
    }
 
}


