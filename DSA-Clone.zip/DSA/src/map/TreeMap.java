package map;
import list.*;
import set.*;
import tree.*;

/** A Map in which entries are stored in a BST.
 * Entries may be accessed in their natural order
 * @author sdb & Nicholas Sin */

public class TreeMap <K extends Comparable, V> implements Map<K,V>{

	BinaryTree<Entry<K, V>> tree = new EmptyBinarySearchTree();
	
	class Entry<K extends Comparable,V> implements Comparable
	{
		K key;
		V value;
		// constructor
		Entry(K key, V value)
		{
			this.key = key;
			this.value = value;
		}
		
		public int compareTo(Object obj)
		{
			Entry<K,V> other = (Entry) obj;
			return this.key.compareTo(other.key);
		}
	} // end inner class
	
	public boolean containsKey(K key) {
		Entry<K,V> entry = new Entry<K,V>(key,null);
		return tree.containsKey(entry);
	}

	public V get(K key) {
		Entry<K,V> entry = new Entry<K,V>(key,null);
		entry = tree.get(entry);
		if(entry==null)
			return null;
		return entry.value;
	}

	public V put(K key, V value) {
		Entry<K,V> newEntry = new Entry<K,V>(key,value),
		oldEntry = tree.get(newEntry);
		if(oldEntry == null)
		{
			tree = tree.add(newEntry);
			return null;
		}
		V result = oldEntry.value;
		oldEntry.value = value;
		return result;
		
	}

	public V remove(K key) {
		Entry<K,V> entry = new Entry<K,V>(key,null);
		entry = tree.get(entry);
		if(entry == null)
			return null;
		tree = tree.remove(entry);
		return entry.value;
	}

	public int size() {
	    return tree.size();
	}

	public boolean isEmpty() {
	    return tree.isEmpty();
	}

	public void clear() {
	    tree = new EmptyBinarySearchTree<>();
	}

	public K getKey(V value) {
        Iterator<Entry<K, V>> iterator = tree.iterator();
        while (iterator.hasNext()) {
            Entry<K, V> entry = iterator.next();
            if (value.equals(entry.value)) {
                return entry.key;
            }
        }
        return null;
    }

	public Set<K> keySet() {
	    Set<K> keys = new TreeSet<K>();
	    Iterator<Entry<K, V>> iterator = tree.iterator();
	    while (iterator.hasNext()) {
	        Entry<K, V> entry = iterator.next();
	        keys.add(entry.key);
	    }
	    return keys;
	}
	
	public boolean equals(Object obj) {
	    if (obj == this) {
	        return true;
	}
	    if (!(obj instanceof Map)) {
	        return false;
	    }
	    Map<K, V> other = (Map<K, V>) obj;
	    if (other.size() != size()) {
	        return false;
	    }
	    Set<K> keys = keySet();
	    Iterator<K> iterator = keys.iterator();
	    while (iterator.hasNext()) {
	        K key = iterator.next();
	        V value = get(key);
	        if (!other.containsKey(key) || !value.equals(other.get(key))) {
	            return false;
	        }
	    }
	    return true;
	}
	
	
	public String toString() {
	    StringBuilder sb = new StringBuilder();
	    sb.append("[");
	    Iterator<Entry<K, V>> iterator = tree.iterator();
	    if (iterator.hasNext()) {
	        Entry<K, V> entry = iterator.next();
	        sb.append(entry.key).append("=").append(entry.value);
	    }
	    while (iterator.hasNext()) {
	        Entry<K, V> entry = iterator.next();
	        sb.append(", ").append(entry.key).append("=").append(entry.value);
	    }
	    sb.append("]");
	    return sb.toString();
	}
	
	

}
