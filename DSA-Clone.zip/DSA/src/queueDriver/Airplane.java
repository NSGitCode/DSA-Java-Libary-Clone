package queueDriver;

/**
 * An Airplane has a flight number, an arrival time, and a fuel level.
 * 
 * @author (sdb) 
 * @version (2020)
 */

public class Airplane implements Comparable {
    // Airplane fields
    int flight;
    int arrivalTime;
    int fuelLevel;       // gallons of jet fuel remaining

    // Airplane constructor
    public Airplane(int arrival, int fuel, int flight) {
        arrivalTime = arrival;
        fuelLevel = fuel;
        this.flight = flight;
        System.out.println(this);
    }

    // Use the toString method to print the objects
    public String toString() {
        return "Airplane [flight=" + flight + ", arrivalTime=" + arrivalTime + ", fuelLevel=" + fuelLevel + "]";
    }

    
    public int compareTo(Object obj) {
    	Airplane other = (Airplane) obj;
    	int timeDifference = other.arrivalTime-this.arrivalTime;
    	int fuelDifference = other.fuelLevel-this.fuelLevel;
    	if(other.fuelLevel < 4 || this.fuelLevel < 4)
    		if(other.fuelLevel != this.fuelLevel)
    			return fuelDifference;	
		return timeDifference;
        
    }

}