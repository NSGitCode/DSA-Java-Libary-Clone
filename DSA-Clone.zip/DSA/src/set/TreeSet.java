package set;

import list.*;
import tree.*;

/**
 * A set implemnted with a BST Values can be accessed in their natural order.
 *
 * @author sdb & Nicholas Sin
 */

public class TreeSet<E extends Comparable> implements Set<E> {

    BinaryTree<E> tree = new EmptyBinarySearchTree<E>();

    public boolean contains(Object obj) {
        return tree.containsKey(obj);
    }

    public boolean add(E value) {
        if (contains(value))
            return false;
        tree = tree.add(value);
        return true;
    }

    public boolean remove(Object obj) {
        if (contains(obj)) {
            tree = tree.remove(obj);
            return true;
        }
        return false;
    }

    public Iterator<E> iterator() {
        return tree.iterator();
    }

    public int size() {
        return tree.size();
    }

    public boolean isEmpty() {
        return tree.isEmpty();
    }

    public void clear() {
        tree = new EmptyBinarySearchTree<>();
    }
    
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof Set)) {
            return false;
        }
        Set<E> set = (Set<E>) obj;
        if (set.size() != this.size()) {
            return false;
        }
        Iterator<E> iterator = set.iterator();
        while (iterator.hasNext()) {
            if(!(this.contains(iterator.next())))
            {
            	return false;
            }
            	
        }
        return true;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        Iterator<E> iterator = iterator();
        if (iterator.hasNext()) {
            E element = iterator.next();
            sb.append(element.toString());
            while (iterator.hasNext()) {
                element = iterator.next();
                sb.append(", ").append(element.toString());
            }
        }
        sb.append("]");
        return sb.toString();
    }
}