package set;

import list.*;

/**
 * A collection of values with no duplicates. No ordering is required
 * 
 * @author sdb & Nicholas Sin
 */

public interface Set<E> {
	/** return true iff this Set contains given obj */
	boolean contains(Object obj);

	/**
	 * Add the given value to this Set if not already in this set
	 * 
	 * @return true iff it was added
	 */
	boolean add(E value);

	/**
	 * Remove the given obj from this Set if possible.
	 * 
	 * @return true iff it was removed
	 */
	boolean remove(Object obj);

	/** @return an Iterator for this Set */
	Iterator<E> iterator();

	/** @return the size of this Set */
	int size();

	/** @return true iff this Set is empty */
	boolean isEmpty();

	/** Clear this Set */
	void clear();
}
