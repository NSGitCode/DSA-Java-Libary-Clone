package set;
import hash.*;
import list.*;

/** An implementation of Set, using a HashTable.
 * @author sdb & Nicholas Sin */

public class HashSet<E> implements Set<E> {
    HashTable<E> table = new HashTable<>();

    public boolean contains(Object obj)
    {
        return table.containsKey(obj);
    }

    public boolean add(E value)
    {
        if (contains(value))
            return false;
        table.put(value);
        return true;
    }

    public boolean remove(Object obj)
    {
        return table.remove(obj);
    }

    public Iterator<E> iterator()
    {
        return table.iterator();
    }

    public int size() {
        return table.size();
    }

    public boolean isEmpty() {
        return table.isEmpty();
    }

    public void clear() {
        table.clear();
    }
    
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof Set)) {
            return false;
        }
        Set<E> set = (Set<E>) obj;
        if (set.size() != this.size()) {
            return false;
        }
        Iterator<E> iterator = set.iterator();
        while (iterator.hasNext()) {
            if(!(this.contains(iterator.next())))
            {
            	return false;
            }
            	
        }
        return true;
    }
    
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        Iterator<E> iterator = iterator();
        if (iterator.hasNext()) {
            E element = iterator.next();
            sb.append(element.toString());
            while (iterator.hasNext()) {
                element = iterator.next();
                sb.append(", ").append(element.toString());
            }
        }
        sb.append("]");
        return sb.toString();
    }

    
}
