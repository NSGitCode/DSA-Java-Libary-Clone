package hashDriver;

import java.util.*;

public class HomeTown {
    String city;
    String state;
    String zip;

    public HomeTown(String city, String state, String zip) {
        this.city = city;
        this.state = state;
        this.zip = zip;
    }

    public String getCity() {
        return city;
    }

    public String getState() {
        return state;
    }

    public String getZip() {
        return zip;
    }

    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        HomeTown other = (HomeTown) obj;
        return Objects.equals(zip, other.zip);
    }

    public int hashCode() {
        int result = 17;
        result = 31 * result + city.hashCode();
        result = 31 * result + state.hashCode();
        result = 31 * result + zip.hashCode();
        return result;
    }

    @Override
    public String toString() {
        return "HomeTown{" + city + ", " + state + ", " + zip + '}';
    }
}