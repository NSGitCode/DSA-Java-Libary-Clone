package hashDriver;

import java.util.*;

public class Student {
    String name;
    String id;
    double gpa;
    HomeTown homeTown;
    int cCompleted;

    public Student(String name, String id, int cCompleted, HomeTown homeTown) {
        this.name = name;
        this.id = id; // initialize id variable here
        this.cCompleted = cCompleted;
        this.homeTown = homeTown;
    }

    public String getName() {
        return name;
    }

    public String getID() {
        return id;
}

    public double getGPA() {
        return gpa;
    }

    public int getCCompleted() {
        return cCompleted;
    }

    public HomeTown getHomeTown() {
        return homeTown;
    }

    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        Student other = (Student) obj;

        return Objects.equals(name, other.name)
                && homeTown.equals(other.homeTown)
                && cCompleted == other.cCompleted;
    }


    public int hashCode() {
        int result = 17;
        result += 31 * result + name.hashCode();
        result += 31 * result + id.hashCode();
        result += 31 * result + homeTown.hashCode();
        result += 31 * result + cCompleted;
        return result;
    }

    public String toString() {
        return "Student{" + name + ", " + id + ", " + cCompleted + ", " + homeTown + '}';
    }

}