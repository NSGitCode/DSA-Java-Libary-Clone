package hashDriver;

import hash.*;


public class StudentDriver {
    public static void main(String[] args) {
        HashTable<Student2> roster = new HashTable<Student2>(3);

        Student2 student1 = new Student2("Alice", 12345, 3.5, "alice@example.com");
        Student2 student2 = new Student2("Bob", 23456, 3.6, "bob@example.com");
        Student2 student3 = new Student2("Charlie", 34567, 3.7, "charlie@example.com");

        roster.put(student1);
        roster.put(student2);
        roster.put(student3);

        System.out.println("Number of collisions: " + roster.getNumCollisions());
    }
}