package misc;
import java.util.*;


/**
 * Work with lists
 * 
 * @author (nsin)
 * @author (Nicholas Sin)
 * @version (Spring 2024)
 */
public class Lab1
{   static int MAX = 1000000;
    public static void main(String [] args)
    {
        //List<Integer> myList = new List<Integer>();
        // 'List' is abstract; cannot be instantiated directly. (Syntax Error) The list is the interface and creates a new class that would implement the interface.
        List<Integer> myList = new LinkedList<Integer>();
        // I chose LinkedList instead of ArrayList is that LiknedList has a fast insertion and deletion,
        init (myList);
        System.out.println ("First 20 numbers before removing evens");
        show (myList,20);
        deleteEvens(myList);
        System.out.println ();
        System.out.println ("First 20 numbers after removing evens");
        show (myList,20);
        System.out.println ("\n\nsize is now " + myList.size());
    }
    /**
     *  Delete all even numbers from the given list
     */
    private static void deleteEvens(List<Integer> aList)
    {
        /**
         *  Uses iterator through the list
         */

        for (Iterator<Integer> it = aList.iterator(); it.hasNext(); )
        {
            Integer integer = it.next(); // removes even numbers
                if ((integer % 2) == 0) {
                    it.remove();
                }
            }

    }
  
//     Initialize the given list with MAX integers
    private static void init (List<Integer> aList)
    {
        Random rand = new Random(1);
        for (int i=0; i<MAX; i++)
            aList.add(rand.nextInt(100));
    }
    
//     Display the first max numbers from the given List on stdout
    private static void show (List<Integer> aList, int max)
    {
        for (int i=0; i<max; i++)
            System.out.print (aList.get(i) + " ");
    }
    
    
}
