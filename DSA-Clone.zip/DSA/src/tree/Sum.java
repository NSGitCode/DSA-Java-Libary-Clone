package tree;

/** A Sum represents addition of Expression
 @author sdb & Nicholas Sin */

public class Sum extends Expr {
    //Constructor
    public Sum(Expr left, Expr right)
    {
        super(left,right);
    }

    public int eval()
    {
        return left.eval() + right.eval();
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof Sum))
        {
            return false;
        }
        Sum other = (Sum) obj;
        return left.equals(other.left) && right.equals(other.right) //x+y = x+y
        || left.equals(other.right) && right.equals(other.left); //x+y = y+x
    }

    public Expr simplify() {
        left = left.simplify();
        right = right.simplify();
        if(left instanceof Constant && left.eval() == 0) //o+x=x
            return right;

        if(right instanceof Constant && right.eval() == 0) //o+x=x
            return left;

        return this;
    }

    public String toString() { //infix form
        return "(" + left.toString() + "+" + right.toString() + ")";
    }
}
