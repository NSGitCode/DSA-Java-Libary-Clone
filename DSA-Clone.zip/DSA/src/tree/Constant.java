package tree;

/**
 * A Constant as an int value
 * 
 * @author sdb & Nicholas Sin
 */
public class Constant extends Expr {
	int value;

	// constructor
	public Constant(int value) {
		super(null, null);
		this.value = value;
	}

	public int eval() {
		return value;
	}

	public boolean equals(Object obj) {
		if (!(obj instanceof Constant)) {
			return false;
		}
		Constant other = (Constant) obj;
		return this.value == other.value;
	}

	public Expr simplify() {
		return this;
	}

	public String toString() {
		return value + "";
	}
}
