package tree;

/**
 * An Expression man have two operands, each of which id sn Expression
 * 
 * @author sdb & Nicholas Sin
 */

public abstract class Expr {
	Expr left, right;

	public Expr(Expr left, Expr right) {
		this.left = left;
		this.right = right;
	}

	/**
	 * @return the int value of an Expression, if possible.
	 */
	public abstract int eval();

	/**
	 * @return true iff this Expression equals obj
	 */

	public abstract boolean equals(Object obj);

	/**
	 * @return a simplified version of this Expression
	 */

	public abstract Expr simplify();
}
