package tree;

public class Assign extends Expr {

    public Assign(Expr left, Expr right) {
        super(left,right);
    }

    public int eval() {
        Variable x = (Variable) left;
        x.value = right.eval();
        x.empty = false;
        return left.eval();
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof Assign))
        {
            return false;
        }
        Assign other = (Assign) obj;
        return left.equals(other.left) && right.equals(other.right);
    }

    public Expr simplify() {
        right = right.simplify();
        return this;
    }

    public String toString() {
        return "(" + left + " = " + right + ")";
    }
}