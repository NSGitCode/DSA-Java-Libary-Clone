package tree;

import list.*;

/** A Binary Tree with left child smaller,
 * right child larger, each nonEmpty is also a BST
 * @author sdb & Nicholas Sin */

public class BinarySearchTree <E extends Comparable> implements BinaryTree<E>
{
    E value;

    int size = 1;
    BinaryTree<E> left = new EmptyBinarySearchTree<E>(),
    right = new EmptyBinarySearchTree<E>();

    static boolean added;
    static boolean removed;
    public BinarySearchTree(E value)
    {
        this.value = value;
    }

    public E getValue() {
        return value;
    }

    public E get(E value) {
        int cmp = this.value.compareTo(value);
        if(cmp == 0)
            return this.value;
        if(cmp <0)
            return right.get(value);
        return left.get(value);
    }

    public boolean containsKey(Object obj) {
        try {
            E value = (E) obj;
            int cmp = this.value.compareTo(value);
            if (cmp==0)
                return true;
            if(cmp<0)
                return right.containsKey(obj);
            return left.containsKey(obj);
        }
        catch (Exception cce)
        {
            return false;
        }
    }

    public BinaryTree<E> add(E value) {
        added = false;
        return addHelper(value);
    }

    public BinaryTree<E> getLeft() {
        return left;
    }

    public BinaryTree<E> getRight() {
        return right;
    }

    public int size() {
        return size;
    }

    public boolean isEmpty() {
        return false;
    }

    public void setValue(E value) {
        this.value = value;
    }

    /** Set the left child of this Binary tree to the given Binary Tree */
    public void setLeft(BinaryTree <E> left)
    {  this.left = left;
        size = left.size() + right.size() + 1;
    }

    /** Set the right child of this Binary tree to the given BinaryTree */
    public void setRight(BinaryTree <E> right)
    {  this.right = right;
        size = left.size() + right.size() + 1;
    }

    public BinaryTree<E> remove(Object obj) {
        try {
            removed = false;
            E value = (E) obj;
            return removeHelper(value);
        } catch (ClassCastException cce) {
            return this;
        }
    }

    private BinaryTree<E> removeHelper(E value) {
        int cmp = this.value.compareTo(value);
        if (cmp == 0) {
            removed = true;
            List<BinaryTree<E>> kids = children();
            if (kids.size() == 0)
                return new EmptyBinarySearchTree<>();
            if (kids.size() == 1)
                return kids.get(0);
            // Two Children
            BinaryTree<E> successor = getSucessor();
            removeHelper(successor.getValue());
            this.value = successor.getValue();
            // size--;
            return this;
        }
        if (cmp < 0)
            right = right.remove(value);
        if (cmp > 0)
            left = left.remove(value);
        if (removed)
            size--;
        return this;
    }

    private BinaryTree<E> addHelper(E value){
        int cmp = this.value.compareTo(value);
        if(cmp<0)
            right = right.add(value);
        if(cmp>0)
            left = left.add(value);
        if(added)
            size++;
        return this;
    }

    private List<BinaryTree<E>> children()
    {
        List<BinaryTree<E>> result = new ArrayList<BinaryTree<E>>(); {
            if (!left.isEmpty())
                result.add(left);

            if (!right.isEmpty())
                result.add(right);

            return result;
        }
    }

    //return the sucessor
    //of this BinaryTree

    private BinaryTree<E> getSucessor() {
        BinaryTree<E> result = right;
        while (!result.isEmpty() && !result.getLeft().isEmpty()) {
            result = result.getLeft();
        }
        return result;
    }

    public Iterator<E> iterator()
    {
        return new TreeIterator<E>(this);
    }

    public void clear() {
        value = null;
        left = new EmptyBinarySearchTree<>();
        right = new EmptyBinarySearchTree<>();
        size = 0;
    }


    public String toString() {
        StringBuilder sb = new StringBuilder("[");
        Iterator<E> iterator = iterator();
        if (iterator.hasNext()) {
            sb.append(iterator.next());
        }
        while (iterator.hasNext()) {
            sb.append(", ");
            sb.append(iterator.next());
        }
        return sb.append("]").toString();
    }


}
