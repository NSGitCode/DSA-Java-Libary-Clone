package tree;
import list.*;
import queue.*;

/** An Iterator for BinaryTrees,
 * using an InOrder traversal.
 * @author sdb & Nicholas Sin */

class TreeIterator<E> implements Iterator<E>{
    BinaryTree<E> tree;

    E lastGotten; //returned by next()

    QueueADT<E> queue = new Queue<E>();

    //Constructor
    TreeIterator(BinaryTree<E> tree)
    {
        this.tree = tree;
        buildQ(tree);
    }

    //Add all values from tree to the queue.
    private void buildQ(BinaryTree<E>tree)
    {
        if(tree.isEmpty())
            return;
        buildQ(tree.getLeft());
        queue.add(tree.getValue());
        buildQ(tree.getRight());

    }

    public boolean hasNext() {
        return !queue.isEmpty();
    }

    public E next()
    {
        //return queue.remove();
        lastGotten = queue.remove();
        return lastGotten;
    }

    public void remove()
    {
        if(lastGotten.equals(tree.getValue()) && tree.getLeft().isEmpty() != tree.getRight().isEmpty()) //1 child
        {
            BinaryTree<E> kid = tree.getLeft();
            if(kid.isEmpty())
                kid = tree.getRight(); //kid as the only child
                tree.setValue(kid.getValue());
                tree.setLeft(kid.getLeft());
                tree.setRight(kid.getRight());
        }
        else
            tree = tree.remove(lastGotten);
    }



}
