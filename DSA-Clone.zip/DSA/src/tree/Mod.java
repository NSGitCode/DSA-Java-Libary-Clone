package tree;

/**
 * A Mod represents modulus of Expression
 * 
 * @author Nicholas Sin
 */

public class Mod extends Expr {
	// Constructor
	public Mod(Expr left, Expr right) {
		super(left, right);
	}

	public int eval() {
		return left.eval() % right.eval();
	}

	public boolean equals(Object obj) {
		if (!(obj instanceof Mod)) {
			return false;
		}
		Mod other = (Mod) obj;
		return left.equals(other.left) && right.equals(other.right); // x%y = x%y
	}

	public Expr simplify() {
		left = left.simplify();
		right = right.simplify();

		return this;
	}

	public String toString() { // infix form
		return "(" + left.toString() + "%" + right.toString() + ")";
	}
}