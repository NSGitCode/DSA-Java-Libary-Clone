package tree;

/**
 * A Difference represents subtraction of Expression
 * 
 * @author Nicholas Sin
 */

public class Difference extends Expr {
	// Constructor
	public Difference(Expr left, Expr right) {
		super(left, right);
	}

	public int eval() {
		return left.eval() - right.eval();
	}

	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (obj == null || !(obj instanceof Difference))
			return false;
		Difference other = (Difference) obj;
		return left.equals(other.left) && right.equals(other.right);
	}

	public Expr simplify() {
		left = left.simplify();
		right = right.simplify();
		if (right instanceof Constant && right.eval() == 0) // x-0 = x
			return left;
		if (left.equals(right)) // x-x = 0
			return new Constant(0);

		return this;
	}

	public String toString() { // infix form
		return "(" + left.toString() + "-" + right.toString() + ")";
	}
}