package tree;

import list.*;

/**
 * A Binary tree may have a value, and at most two children, each of which is
 * BT.
 * 
 * @author sdb & Nicholas Sin
 */
public interface BinaryTree<E> {
	/**
	 * @return the value of the BT, or null if it is has none
	 */
	E getValue();

	/**
	 * Search the family of this BT for the given value
	 * 
	 * @return that value, or null if not found
	 */

	E get(E value);

	/**
	 * @return true, iff given obj is in this BT's family
	 */

	boolean containsKey(Object obj);

	/**
	 * Add the given value to the BT's family,
	 * 
	 * @return the updated BT's family
	 */

	BinaryTree<E> add(E value);

	/** @return the left child of this BinaryTree */
	BinaryTree<E> getLeft();

	/** @return the right child of this BinaryTree */
	BinaryTree<E> getRight();

	/** @return the size of this BinaryTree's family */
	int size();

	/** @return true iff this BinaryTree is empty */
	boolean isEmpty();

	/** Set the value of this BinaryTree to the given value */
	void setValue(E value);

	/** Set the left child of this BinaryTree to the given BinaryTree */
	void setLeft(BinaryTree<E> left);

	/** Set the right child of this BinaryTree to the given BinaryTree */
	void setRight(BinaryTree<E> right);

	/**
	 * Remove the given Object from this BinaryTree's family, if possible.
	 * 
	 * @return the resulting BinaryTree.
	 */
	BinaryTree<E> remove(Object obj);

	Iterator<E> iterator();

	/** @return this BinaryTree as a String, using an in-order traversal */
	String toString();

	/** Clear this BinaryTree */
	void clear();

}
