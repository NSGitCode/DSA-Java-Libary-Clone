package tree;

/** A Variable represents a variable with a name
 * @author Nicholas Sin */

public class Variable extends Expr {
   // instance variable
    public int value;
    private final char name;

    // constructor
    public Variable(char name) {
        super(null,null);
        this.name = name;
    }

    boolean empty = true;
    public int eval() {
        if (empty) {
            throw new IllegalArgumentException("Variable has no value yet.");
        }
        else {
            return value;
        }

    }

    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null || !(obj instanceof Variable))
            return false;
        Variable other = (Variable) obj;
        return this.name == other.name
            && this.value == other.value;
    }

    public Expr simplify() {
        return this;
    }

    // setters and getters

    public void assign(int value) {
        this.value = value;
    }

    public char getName() {
        return name;
    }

    public String toString() {
        return "" + name ;
    }
}