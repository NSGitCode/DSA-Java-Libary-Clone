package tree;
/** A Product, multiplication has two operands
 @author sdb & Nicholas Sin */

public class Product extends Expr {
    //constructor
    public Product(Expr left, Expr right)
    {
        super(left,right);
    }

    public int eval() {
        return left.eval() * right.eval();
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof Product))
        {
            return false;
        }
        Product other = (Product) obj;
        return left.equals(other.left) && right.equals(other.right) //x*y = x*y
                || left.equals(other.right) && right.equals(other.left); //x*y = y*x
    }

    public Expr simplify() {
        left = left.simplify();
        right = right.simplify();
        if(left instanceof Constant && left.eval() == 0) //0*x=x
            return left;

        if(right instanceof Constant && right.eval() == 0) //x*0=0
            return right;

        if(left instanceof Constant && left.eval() == 1) //1*x=x
            return right;

        if(right instanceof Constant && right.eval() == 1) //x*1=x
            return left;

        return this;
    }

    public String toString() { //infix form
        return "(" + left.toString() + "*" + right.toString() + ")";
    }
}
