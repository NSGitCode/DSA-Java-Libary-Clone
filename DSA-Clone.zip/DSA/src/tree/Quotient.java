package tree;

/**
 * A Quotient represents division of Expression
 * 
 * @author Nicholas Sin
 */

public class Quotient extends Expr {
	// Constructor
	public Quotient(Expr left, Expr right) {
		super(left, right);
	}

	public int eval() {
		return left.eval() / right.eval();
	}

	public boolean equals(Object obj) {
		if (!(obj instanceof Quotient)) {
			return false;
		}
		Quotient other = (Quotient) obj;
		return left.equals(other.left) && right.equals(other.right); // x/y = x/y
	}

	public Expr simplify() {
		left = left.simplify();
		right = right.simplify();

		if (right instanceof Constant && right.eval() == 0) {
			throw new ArithmeticException("Division by zero is undefined.");
		}
		if (left.equals(right)) {
			return new Constant(1);
		}
		if (right instanceof Constant && right.eval() == 1) {
			return left;
		}
		if (left instanceof Constant && left.eval() == right.eval() && right.eval() != 0) {
			return new Constant(1);
		}
		if (left instanceof Constant && left.eval() == 0) {
			return new Constant(0);
		}
		return this;
	}

	public String toString() { // infix form
		return "(" + left.toString() + "/" + right.toString() + ")";
	}
}