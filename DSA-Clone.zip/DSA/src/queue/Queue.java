package queue;

import list.*;

/** A QueueADT using a
 * LinkedList.
 * @author sdb & Nicholas Sin
 */

public class Queue<E> implements QueueADT<E> {
    List<E> list = new LinkedList<E>();

    public void add(E value)
    {
        list.add(value);
    }

    public E peek()
    {
        if(list.isEmpty())
        {
            return null;
        }
        return list.get(0);
    }

    public E remove()
    {
        return list.remove(0);
    }

    public boolean isEmpty() {
        return list.isEmpty();
    }

    public E clear() {
        list.clear();
        return null;
    }

    @Override
    public int size() {
        return list.size();
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Queue: ");
        if(isEmpty()) {
            sb.append("empty");
        } else {
            sb.append("[");
            for(int i = 0; i < list.size(); i++) {
                sb.append(list.get(i));
                if(i < list.size() - 1) {
                    sb.append(", ");
                }
            }
            sb.append("]");
        }
        return sb.toString();
    }

}
