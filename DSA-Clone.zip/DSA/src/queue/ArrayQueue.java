package queue;

import list.LinkedList;
import list.*;

/** A QueueADT using a
 * ArrayList.
 * @author sdb & Nicholas Sin
 */

public class ArrayQueue<E> implements QueueADT<E> {
    List<E> list = new ArrayList<E>();

    int front = 0,
            back = 0,
            size = 0; // size of queue

//    public void add(E value)
//    {
//        if(size == list.size())
//        { //Insertion
//            list.add(back, value);
//            back++;
//            if(back == list.size())
//            {
//                back = 0;
//            }
//        }
//
//    }

    public void add(E value)
    {
        if(size == list.size())
        { //Insertion
            list.add(back, value);
            front = (front+1)%list.size();
        }
        else
        {
            list.set(back,value);
        }
        size++;
        back = (back+1)%list.size();
    }


    public E peek()
    {
        if(size == 0)
        {
            return null;
        }
        return list.get(front);
    }


    public E remove()
    {
        E result = list.get(front);
        front = (front+1)%list.size();
        size--;
        return result;
    }


    public boolean isEmpty() {
        return size == 0;
    }

    public E clear() {
        list.clear();
        return null;
    }

    @Override
    public int size() {
        return size;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("ArrayQueue: ");
        if(isEmpty()) {
            sb.append("empty");
        } else {
            sb.append("[");
            for(int i = 0; i < list.size(); i++) {
                sb.append(list.get(i));
                if(i < list.size() - 1) {
                    sb.append(", ");
                }
            }
            sb.append("]");
        }
        return sb.toString();
    }

}
