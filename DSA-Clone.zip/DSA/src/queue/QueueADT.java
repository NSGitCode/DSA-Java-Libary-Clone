package queue;

/**
 * A FIFO List
 * 
 * @author sdb & Nicholas Sin
 */

public interface QueueADT<E> {
	/**
	 * Add the given value at back of this QueueADT.
	 */

	void add(E value);

	/**
	 * @return value at front of this QueueADT, or null if empty.
	 */
	E peek();

	/**
	 * Remove value at front of this QueueADT.
	 * 
	 * @return value removed. Pre: This QueueADT not empty.
	 */

	E remove();

	/** @return true iff this Queue is empty */
	boolean isEmpty();

	/** Clear the Queue */
	E clear();

	int size();
}
