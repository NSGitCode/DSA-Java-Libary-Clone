package queue;
import list.*;

/** Priority Queue: Always remove the 
 * value with highest priority.
 * @author sdb & Nicholas Sin
 */
public class PriorityQueue <E extends Comparable> implements QueueADT<E>{
	List<E> list = new ArrayList<E>();

	public E peek() {
		if(list.isEmpty())
			return null;
		return list.get(0);
	
	}

	public E remove() {
	    E result = list.get(0);
	    int last = list.size() - 1; 
	    int avail = 0;
	    int bc = biggerChild(avail);

	    while (2 * avail+1 < last && greater(bc, last)) {
	        list.set(avail, list.get(bc));
	        avail = bc;
	        bc = biggerChild(avail);
	    }

	    list.set(avail, list.get(last));
	    list.remove(last);

	    return result;
	}
	
	// Return position of bigger child of given parent
	private int biggerChild(int parent) {
		int left = 2*parent +1, 
		right = 2*parent+2;
		if(right >= list.size()-1)
			return left;
		if(greater(left,right))
			return left;
		return right;
	}
	
	//return true off value at position x
	//greater than value at position y;
	private boolean greater(int x, int y) {
		return list.get(x).compareTo(list.get(y)) > 0;
	}


	public void add(E value) {
		int added = list.size();
		int parent = (added-1)/2;
		list.add(value);
		
		while(added>0 && greater(added, parent))
		{
			swap(added,parent);
			added = parent;
			parent = (added-1)/2;
		}
		
	}
	
	private void swap(int x, int y) {
		E temp = list.get(x);
		list.set(x, list.get(y)); // O(1)
		list.set(y, temp);
	}
	

    public int size() {
        return list.size();
    }


    public boolean isEmpty() {
        return list.isEmpty();

    }

    public E clear() {
        list.clear();
        return null;
    }
    
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        for (int i = 0; i < list.size(); i++) {
            if (i > 0) {
                sb.append(", ");
            }
            sb.append(list.get(i));
        }
        sb.append("]");
        return sb.toString();
    }

	

}

