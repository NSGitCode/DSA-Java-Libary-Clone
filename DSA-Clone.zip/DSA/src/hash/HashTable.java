package hash;
import list.*;


/** A HashTable allows quick access to keys. Client must implement a hashCode() method.
 * if two keys are equal, they must have the same hashCode(), if two keys are not equal,
 * they should have different hashCodes, for effeciency.
 * Duplicate keys are permitted.
 * @author sdb & Nicholas Sin
 */
public class HashTable<K>{
    List<List<K>> lists;
    public int numCollisions;
    int size = 0;
    public HashTable(int listCount)
    {
        lists = new ArrayList<List<K>>(listCount);
        for(int i = 0; i< listCount; i++)
        {
            lists.add(new LinkedList<K>());
        }
    }

    public HashTable()
    {
        this(10);
    }

    /** Put given key onto this HashTable */
    public void put(K key)
    {

        List<K> list = getList(key);
        //System.out.println(list);
        int sizeBAdd = list.size();
        list.add(key);
        size++;
        if((list.size() > sizeBAdd) && list.size() > 1)
        {
            numCollisions++;
        }

    }

    /** @return the LinkedList for the give object */
    private List<K> getList(Object obj)
    {
        int code = obj.hashCode();
        code = Math.abs(code);
        code = code % lists.size();
        return lists.get(code);
    }

    /** @return true iff this HashTable contains given object */
    public boolean containsKey(Object obj)
    {
        List<K> list = getList(obj);
        return list.contains(obj);
    }

    /** @return the first occurance of the given key from this HashTable,
     * or null if not found */
    public K get(K key)
    {
        List<K> list = getList(key);
        int ndx = list.indexOf(key);
        if(ndx <0) return null;
        return list.get(ndx);
    }

    /** Remove first occurrence of given object from this HasTable, if possible.
     * @return true iff it was removed
     * */
    public boolean remove(Object obj)
    {
        List<K> list = getList(obj);
        if(list.remove(obj))
        {
            size--;
            return true;
        }
        return false;
    }

    /** @return the size of this HashTable */
    public int size()
    {
        return size;
    }

    /** @return true iff this HashTable is empty */
    public boolean isEmpty()
    {
        return size == 0;
    }

    /** Clear this HashTable */
    public void clear()
    {
        for (int i = 0; i < lists.size(); i++) {
            lists.get(i).clear();
        }
        size = 0;
    }


    public Iterator<K> iterator() {
        return new TableIterator<K>(this);
    }
    
    /** @return the efficiency rating of this HashTable as a percentage*/
    public int efficiency() {
        if (lists.isEmpty()) {
            return 100; // empty HashTable is 100% efficient
        }

        int minSize = Integer.MAX_VALUE;
        int maxSize = 0;
        for (int i = 0; i < lists.size(); i++) {
            List<K> list = lists.get(i);
            int size = list.size();
            if (size > maxSize) {
                maxSize = size;
            }
            if (size < minSize) {
                minSize = size;
            }
        }

        int efficiency = (minSize * 100) / maxSize;

        if (efficiency < 0) {
            efficiency = 0;
        } else if (efficiency > 100) {
            efficiency = 100;
        }

        return efficiency;
    }

        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append("[");
            Iterator<K> it = iterator();
            if (it.hasNext()) {
                K key = it.next();
                sb.append(key.toString());
                while (it.hasNext()) {
                    key = it.next();
                    sb.append(", ");
                    sb.append(key.toString());
                }
            }
            sb.append("]");
            return sb.toString();
        }

    public int getNumCollisions() {
        return numCollisions;
    }
}

