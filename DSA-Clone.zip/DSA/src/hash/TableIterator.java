package hash;
import list.*;

/** An iterator for HashTables
 *@author sdb & Nicholas Sin */

class TableIterator<K> implements Iterator<K>{

    HashTable<K> table;
    int ndx = 0; //Position of current list

    Iterator<K> listIt; //for LinkedList

    //set the list iterator to the given list, ndx
    private void setListIt(int ndx)
    {
        List<K> list = table.lists.get(ndx);
        listIt = list.listIterator();
    }

    //@return next non-empty LinkedList
    private int nextList()
    {
        for(int i=ndx+1; i<table.lists.size() && ndx<table.lists.size();i++)
        {
            List<K> list = table.lists.get(i);
            if(!list.isEmpty())
                return i;
        }
        return -1;
    }

    //constructor
    TableIterator(HashTable<K> table)
    {
        this.table = table;
        setListIt(0);
    }

    public boolean hasNext()
    {
        if(listIt.hasNext())
            return true;
        if(ndx >= table.lists.size())
            return false;
        return nextList() > ndx;
    }

    public K next() {
        if(!listIt.hasNext())
        {
            ndx = nextList();
            setListIt(ndx);
        }
        return listIt.next();
    }

    public void remove() {
        listIt.remove();
        table.size--;
    }

}
