package recursion;

import list.*;

public class Email {
	private List addressBook;

	public Email(List addressBook) {
		this.addressBook = addressBook;
	}

	public Email() {
	}

	/**
	 * @return All the email addresses corresponding to the given alias, in a List.
	 */
	public List<String> expand(List addresses) {

		//////////// PUT YOU CODE HERE
		List<String> expandedList = new ArrayList<>();
		for (int i = 0; i < addresses.size(); i++) {
			Object item = addresses.get(i);
			if (item instanceof String) {
				expandedList.add((String) item);
			} else if (item instanceof List) {
				List<String> sublist = expand((List) item);
				expandedList.addAll(sublist);
			}
		}
		return expandedList;
	}
}
