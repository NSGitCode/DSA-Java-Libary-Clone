package recursion;

import list.*;

public class LabEmailDriver {
	public static void main(String[] args) {
		Email book = new Email();

		List techstaff = new LinkedList();
		techstaff.add("pat@ex.edu");
		techstaff.add("chris@ez.edu");

		List bobby = new LinkedList();
		bobby.add("bob@cs.org");
		List ana = new LinkedList();
		ana.add("ana@ez.edu");
		List faculty = new LinkedList();
		faculty.add("sam@ez.edu");
		faculty.add(bobby);
		faculty.add(ana);
		List contacts = new LinkedList();
		contacts.add("phil@ez.edu");
		contacts.add(faculty);
		contacts.add(techstaff);

		System.out.println("techstaff: " + book.expand(techstaff));
		System.out.println("faculty: " + book.expand(faculty));
		System.out.println("contacts: " + book.expand(contacts));

		if (book.expand(contacts).size() != 6)
			System.err.println("Error: there should be a total of 6 contacts");
		System.out.println("\nTesting complete");
	}

}
