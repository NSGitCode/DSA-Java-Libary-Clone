package recursion;
import list.*;

import java.util.Scanner;


public class RecTestDriver {

    public static void main (String[] args) {

        // read expression from the keyboard
        Scanner sc = new Scanner (System.in);
        System.out.println("First Value:");
        int x = sc.nextInt();
        System.out.println("Second Value:");
        int y = sc.nextInt();
        int result = Recursion.div(x,y);
        System.out.println("The qoutient of " + x + " / " + y + " is " + result);

    }
}
