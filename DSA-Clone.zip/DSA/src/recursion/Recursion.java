package recursion;

public class Recursion {

	// Examples of Recursive Functions

	/** fib */
	int fib(int n) {
		if (n < 2) {
			return 1;
		}
		return fib(n - 1) + fib(n - 1);
	}

	/**
	 * return n!
	 * 
	 * @param n>=0
	 */
	int fact(int n) {
		if (n == 0) // Base Case
		{
			return 1;
		}
		return n * fact(n - 1); // recursive case
	}

	/** Pre n>=0 */
	int mult(int n, int m) {
		if (n == 0) {
			return 0;
		}
		return m + mult(n - 1, m); // recursive case
	}

	/**
	 * @return trueiff given string is a palindrome
	 */
	boolean pal(String str) {
		if (str.length() < 2) // base cases
		{
			return true;
		}
		if (str.charAt(0) != str.charAt(str.length() - 1)) {
			return false;
		}

		String mid = str.substring(1, str.length() - 1);
		return pal(mid); // recursive
	}

	/**
	 * @return the integer quotient when x is divided by y, using recursion.
	 * @param x is not negative, y is positive
	 */
	static int div(int x, int y) {
		if (y == 1)
			return x;

		if (y > x)
			return 0;

		return 1 + div(x - y, y);
	}

	/**
	 * @return the remainder when x is divided by y. Pre: x>=0, y>0
	 */
	public int mod(int x, int y) {
		if (x - y < 0 || y <= 0 || y <= 0) {
			return 0;
		} else {
			return 1 + div(x - y, y);
		}
	}
}
