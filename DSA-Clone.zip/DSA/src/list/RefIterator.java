package list;

/**
 * An Iterator for LinkedLists
 * 
 * @author sdb & Nicholas Sin
 *
 *         Also known as RefIterator
 */

class RefIterator<E> implements Iterator<E> {
	LinkedList<E> list;

	Node<E> cursor;

	// Cursor is a ref to the las
	// Node obtained by next()

	// Constructor
	RefIterator(LinkedList<E> list) {
		this.list = list;
		cursor = list.head;
	}

	// Default constructor
	RefIterator() {

	}

	public boolean hasNext() {
		return cursor.next != list.tail;
	}

	public E next() {
		cursor = cursor.next;
		return cursor.value;
	}

	public void remove() {
		cursor.prev.next = cursor.next;
		cursor.next.prev = cursor.prev;
		list.size--;
	}

}
