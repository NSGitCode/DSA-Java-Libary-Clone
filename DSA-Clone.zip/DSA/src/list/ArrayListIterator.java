package list;

/**
 * A ListIterator for ArrayLists.
 *
 * @author sdb & Nicholas Sin
 */
class ArrayListIterator<E> extends ArrayIterator<E> implements ListIterator<E> {
	// Implement cursor is between positions ndx, ndx+

	boolean foreword = true;

	// constructors
	ArrayListIterator(List<E> list) {
		super(list);
	}

	/**
	 * Given a start position Start = 0 => start at beginning. start = size => start
	 * at end*;
	 */

	ArrayListIterator(List<E> list, int start) {
		super(list);
		ndx = start - 1;
	}

	public boolean hasPrevious() {
		return ndx >= 0;
	}

	public E previous() {
		foreword = false;
		ndx--;
		return list.get(ndx + 1);
	}

	public E next() {
		foreword = true;
		return super.next();

	}

	public void remove() {
		if (foreword) {
			list.remove(ndx);
			ndx--;
		} else {
			// backward
			list.remove(ndx + 1);
		}
	}

	public void add(E value) {
		ndx++;
		list.add(ndx, value);

	}

}
