package list;

/**
 * Permit iteration Through a collection
 * 
 * @author sdb & Nicholas Sin
 */
public interface Iterator<E> {
	/**
	 * @return true iff there are more values.
	 */
	boolean hasNext();

	/**
	 * @return the next value from the collection.
	 *
	 *         Pre: hasNext() is true
	 */
	E next();

	/**
	 * Remove the last value obtained by next() from the collection.
	 *
	 * Pre: Next(0 was called at least once since last call to remove();
	 */

	void remove();

}
