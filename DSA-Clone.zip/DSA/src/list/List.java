package list;

/** An ordered collection.
 *
 * @author sdb & Nicholas Sin
 */

public interface List <E>{
    /** @return value at
     * give ndx.
     * @param 0 <= ndx < size */

    E get(int ndx);

    /** Change value at
     * given ndx to given
     * value
     * @return old value
     * @param 0 <= ndx < size */

    E set (int ndx, E value);

    /** Add given value at
     *  end of this list */

    void add(E value);

    /** Insert given value
     * at given ndx
     * @param 0 <= ndx < size */

    void add(int ndx, E value);

    /** Remove the value
     * at given ndx
     * @return value removed
     * @param 0 <= ndx < size */
    E remove (int ndx);

    /** @return the size of this List */

    int size();

    /** @return true iff this List is empty */

    boolean isEmpty();

    /** Clear this List */

    void clear();

    /** @return the index of the given object in this List, or -1 if not found */
    int indexOf(Object obj);

    /** @return true iff this List contains the given object */
    boolean contains(Object obj);

    /** @return an Iterator
     * for this List
     */
    Iterator<E> iterator();

    /** @return true iff the first value in this List matches the last value */
    boolean endsWithStart();

    /** Remove the first occurrence of obj from this List, if possible.
     @return true iff the object was removed
     */
    boolean remove (Object obj);

    /** return a ListIterator
     * for this list
     */

    ListIterator<E> listIterator();

    /** @return a list, starting at given start position
     *
     */
    ListIterator<E> listIterator(int start);

    /** @return a List in which the values of this List are in reverse order.
     */
    List<E> reversed();

    /** Add all the elements of the given List to this List */
    void addAll (List<E> otherList);
}


