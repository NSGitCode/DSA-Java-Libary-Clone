package list;

/**
 * A ListIterator for LinkedLists
 *
 * @author sdb & Nicholas Sin
 */
class RefListIterator<E> extends RefIterator<E> implements ListIterator<E> {

	// supercursor is ref to last value obtained in next() or prev();

	boolean foreward = true;

	// Constructors

	RefListIterator(LinkedList<E> list) {
		super(list);
	}

	RefListIterator(LinkedList<E> list, int start) {
		super(list);
		for (int i = 0; i < start; i++) {
			cursor = cursor.next;
		}
	}

	public boolean hasNext() {
		if (list.isEmpty()) {
			return false;
		}
		if (foreward) {
			return cursor.next != list.tail;
		}
		return true;
	}

//    public E next()
//    {
//        if(foreward)
//        {
//            cursor = cursor.next;
//            return cursor.value;
//        }
//        foreward = true;
//        return cursor.value;
//    }

	public E next() {
		if (foreward) {
			cursor = cursor.next;
		}
		foreward = true;
		return cursor.value;
	}

	@Override
	public boolean hasPrevious() {
		if (!foreward) {
			return cursor.prev != list.head;
		}
		// don't return true
		return cursor != list.head;
	}

	@Override
	public E previous() {
		if (!foreward)
			cursor = cursor.prev;
		foreward = false;
		return cursor.value;
	}

	@Override
	public void remove() {
		super.remove();
		if (foreward) {
			cursor = cursor.prev;
		} else {
			cursor = cursor.next;
		}
	}

	@Override
	public void add(E value) {
		if (foreward) {
			cursor.next = new Node<>(value, cursor.next, cursor);
			cursor.next.next.prev = cursor.next;
		} else {
			cursor.prev = new Node<>(value, cursor.prev, cursor);
			cursor.prev.prev.next = cursor.prev;
		}
	}

	public void set(E value) {
		cursor.value = value;
	}
}
