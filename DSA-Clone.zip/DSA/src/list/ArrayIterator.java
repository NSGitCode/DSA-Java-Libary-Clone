package list;

/** An Iterator for ArrayLists
 * @author sdb & Nicholas Sin
 */

class ArrayIterator<E> implements Iterator<E>{

    //ndx is the position of the last
    //value returned by next()

    int ndx = -1;

    List<E> list;

    //constructor

    ArrayIterator(List<E> list)
    {
        this.list = list;
    }

    //Default constructor
    ArrayIterator()
    {

    }

    public boolean hasNext()
    {
        return ndx<list.size()-1;
    }

    public E next()
    {
        ndx++;
        return list.get(ndx);
    }

    public void remove()
    {
        list.remove(ndx);
        ndx--;
    }
}
