package list;

/** A list implemented with references.
 *
 * @author sdb & Nicholas Sin
 *
 */

public class LinkedList<E> implements List<E> {

    int size = 0;
    Node<E> head = new Node<E> (null, null, null);
    Node<E> tail = new Node<E> (null, null, head);
    Node<E> ref;

    public LinkedList()
    {
        head.next = tail;
    }


    public E get(int ndx)
    {
        setRef(ndx); //ref now refers to the node at position (ndx)

        return ref.value;
    }

    //POST CONDITION: ref refers to the node at position (ndx)
    private void setRef(int ndx)
    {
        if(ndx > size / 2)
        {
            ref = tail.prev;
            for(int i = size-1; i > ndx; i--)
            {
                ref = ref.prev;
            }
        }
        else
        {
            ref = head.next; // Node at position 0

            for(int i = 0; i < ndx; i++)
            {
                ref = ref.next;
            }
        }

    }

    public E set(int ndx, E value)
    {
        setRef(ndx);

        E result = ref.value;

        ref.value = value;

        return result;
    }

    public void add(E value)
    {
        Node<E> temp = new Node<E>(value, tail, tail.prev);

        tail.prev.next = temp;

        tail.prev = temp;

        size++;
    }

    public void add(int ndx, E value)
    {
        setRef(ndx);

        Node<E> temp = new Node<E> (value, ref, ref.prev);

        ref.prev.next = temp;

        ref.prev = temp;

        size++;
    }

    public E remove(int ndx)
    {
        setRef(ndx);

        ref.prev.next = ref.next;
        ref.next.prev = ref.prev;

        size--;

        return ref.value;
    }

    public int size()
    {
        return size;
    }

    public boolean isEmpty()
    {
        if(size == 0)
        {
            return true;
        }

        return false;
    }

    public void clear()
    {
        head.next = tail;
        tail.prev = head;
        size = 0;
    }

    //Lab 2 problem 2
    public int indexOf(Object obj)
    {
        ref = head.next;

        if(size != 0)
        {
            for(int i = 0; i < size; i++)
            {
                if(ref.value.equals(obj))
                {
                    return i;
                }
                else
                    ref = ref.next;
            }
        }

        return -1;
    }

    //Lab 2 problem 2
    public boolean contains(Object obj)
    {
        ref = head.next;

        if(size != 0)
        {
            for(int i = 0; i < size; i++)
            {
                if(ref.value.equals(obj))
                {
                    return true;
                }
                else
                    ref = ref.next;
            }
        }

        return false;
    }

    //Lab 2 problem 3
    public String toString()
    {
        if(isEmpty())
        {
            return "[]";
        }

        ref = head.next;

        String result = "[" +ref.value;

        for(int i = 1; i < size; i++)
        {
            ref = ref.next;
            result = result +", "+ ref.value;
        }

        result = result+ "]";

        return result;
    }

    public Iterator<E> iterator()
    {
        return new RefIterator<E>(this);
    }

    //Quiz 1 Problem 2
    public boolean endsWithStart()
    {
        if(size == 0)
        {
            return true;
        }

        E last = (E) tail.prev;
        ref = head.next;

        if(ref.value.equals(last))
        {
            return true;
        }

        return false;

    }

    //Lab3 problem 1
    public boolean remove(Object obj)
    {
        Iterator<E> it = this.iterator();

        while(it.hasNext())
        {
            E result = it.next();

            if(result.equals(obj))
            {
                it.remove();
                return true;
            }
        }

        return false;
    }

    //Lab3 Problem 2
    /** @return true iff the given Object is a List and this List is equal to the given List. */
    public boolean equals (Object obj)
    {
        if(!(obj instanceof List))
        {
            return false;
        }

        List<E> other = (List) obj;

        if(this.size() != other.size())
        {
            return false;
        }

        Iterator<E> it = this.iterator();
        Iterator<E> it2 = other.iterator();

        while(it.hasNext())
        {
            if(!(it.next().equals(it2.next())))
            {
                return false;
            }
        }

        return true;
    }

    public ListIterator<E> listIterator()
    {
        return new RefListIterator<E>(this);
    }

    public ListIterator<E> listIterator(int start)
    {
        return new RefListIterator<E>(this, start);
    }

    //Quiz 2 Problem 2
    public List<E> reversed()
    {
        ListIterator<E> lit = listIterator(size);

        List<E> result = new LinkedList<E>();

        while(lit.hasPrevious())
        {
            result.add(lit.previous());
        }

        return result;
    }

    public void addAll(List<E> otherList)
    {
        for(int i = 0; i < otherList.size();i++)
        {
            E val = otherList.get(i);
            this.add(val);
        }
    }
}