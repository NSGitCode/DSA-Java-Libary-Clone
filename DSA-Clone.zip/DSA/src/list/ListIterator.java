package list;

/** An Iterator which goes
 * in both directions for
 * Lists.
 * @author sdb & Nicholas Sin
 */

public interface ListIterator <E> extends Iterator<E>{
    /** @return true iff there is a
     * previous value
     */
    boolean hasPrevious();

    /** @return previous
     * value
     */

    E previous();

    /** remove value returned
     * by a call to next() or
     * previous()
     * Pre: next() or previous was called since last call to remove().*;
     */

    void remove();

    /** Insert the given value just prior to the implicit cursor position. A subsequent
     call to previous() should return the inserted value, and a subsequent call to next() should be
     unaffected.
     */
    public void add (E value);

}
