package list;

/** A list implemented with
 * an array.
 *
 * @author sdb & Nicholas Sin
 *
 */

public class ArrayList<E> implements List<E>{

    int size = 0;
    E[] values;

    public ArrayList(int cap)
    {
        values = (E[]) new Object[cap];
    }

    public ArrayList()
    {
        this(10);
    }

    public E get(int ndx)
    {
        return values[ndx];
    }

    public E set(int ndx, E value)
    {
        E result = values[ndx];

        values[ndx] = value;

        return result;
    }

    public void add(E value)
    {
        add(size, value);
    }

    public void add(int ndx, E value)
    {
        if(size == values.length)
        {
            alloc();
        }

        for(int i = size; i > ndx; i--)
        {
            values[i] = values[i-1];
        }

        values[ndx] = value;
        size++;
    }

    //Helper method... method is called if you need bigger array
    //Allocate a bigger array
    private void alloc()
    {
        E[] temp = (E[]) new Object[2 * values.length];

        for(int i = 0; i < size; i++)
        {
            temp[i] = values[i];
        }

        values = temp;
    }

    public E remove(int ndx)
    {
        E result = values[ndx];

        for(int i = ndx; i < size - 1; i++)
        {
            values[i] = values[i+1];
        }

        size--;
        return result;
    }

    public int size()
    {
        return size;
    }

    public boolean isEmpty()
    {
        if(size == 0)
        {
            return true;
        }

        return false;
    }

    public void clear()
    {
        size = 0;
    }

    //Lab 2 problem 1
    public int indexOf(Object obj)
    {
        if(size != 0)
        {
            for(int i = 0; i < size; i++)
            {
                if(values[i].equals(obj))
                {
                    return i;
                }
            }
        }

        return -1;
    }

    //Lab 2 problem 1
    public boolean contains(Object obj)
    {
        if(size != 0)
        {
            for(int i = 0; i < size; i++)
            {
                if(values[i].equals(obj))
                {
                    return true;
                }
            }
        }

        return false;
    }

    //Lab 2 problem 3
    public String toString()
    {
        if(isEmpty())
        {
            return "[]";
        }

        String result = "[" +values[0];

        for(int i = 1; i < size; i++)
        {
            result = result +", "+ values[i];
        }

        result = result+ "]";

        return result;
    }

    public Iterator<E> iterator()
    {
        return new ArrayIterator<E>(this);
    }

    public boolean endsWithStart()
    {
        return true; //under construction
    }

    //Lab3 problem 1
    public boolean remove(Object obj)
    {

        Iterator<E> it = this.iterator();

        while(it.hasNext())
        {
            E result = it.next();

            if(result.equals(obj))
            {
                it.remove();
                return true;
            }
        }

        return false;

    }

    //Lab3 problem 2
    /** @return true iff the given Object is a List and this List is equal to the given List. */
    public boolean equals (Object obj)
    {
        if(!(obj instanceof List))
        {
            return false;
        }

        List<E> other = (List) obj;

        if(this.size() != other.size())
        {
            return false;
        }

        Iterator<E> it = this.iterator();
        Iterator<E> it2 = other.iterator();

        while(it.hasNext())
        {
            if(!(it.next().equals(it2.next())))
            {
                return false;
            }
        }

        return true;
    }

    public ListIterator<E> listIterator()
    {
        return new ArrayListIterator<E>(this);
    }

    public ListIterator<E> listIterator(int start)
    {
        return new ArrayListIterator<E>(this, start);
    }

    public List<E> reversed()
    {
        return null; //stubbbbb
    }

    public void addAll(List<E> otherList)
    {
        // stubbbb
    }


}
