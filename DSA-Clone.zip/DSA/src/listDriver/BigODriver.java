package listDriver;
import java.util.*;


public class BigODriver {
    public static void main(String[] args) {
        int n = 10;
        List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5);

        System.out.println("Method 1: O(n^2)");
        method1(n);

        System.out.println("Method 2: O(n^2) for ArrayList");
        method2(numbers);

        System.out.println("Method 2: O(n^3) for LinkedList");
        method2(numbers);

        System.out.println("Method 3: O(log n)");
        method3(n);
    }

    static void method1(int n) {
        for (int i=0; i<n; i++) {
            for (int j=0; j<i; j++) {
                System.out.println(i + j);
            }
        }
    }

    static void method2(List<Integer> numbers) {
        for (int i=0; i < numbers.size(); i++) {
            for (int j=0; j < numbers.size(); j++) {
                System.out.println(numbers.get(i) + numbers.get(j));
            }
        }
    }

    static void method3(int n) {
        while (n > 0) {
            System.out.println(n);
            n = n / 2;
        }
    }
}