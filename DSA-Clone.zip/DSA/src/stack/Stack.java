package stack;

import list.*;

/**
 * An implementation of the StackADT interface.
 * 
 * @author sdb & Nicholas Sin
 */

public class Stack<E> implements StackADT<E> {
	List<E> list = new ArrayList<E>();

	// Constructors

	public Stack(boolean arrayBased) {
		if (!arrayBased) {
			list = new LinkedList<E>();
		}
	}

	public Stack() {

	}

	public E push(E value) {
		list.add(value);
		return value;
	}

	public E peek() {
		return list.get(list.size() - 1);
	}

	public E pop() {
		return list.remove(list.size() - 1);

	}

	public E clear() {
		list.clear();
		return null;
	}

	public boolean isEmpty() {
		return list.isEmpty();
	}

	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("Stack: ");
		if (isEmpty()) {
			sb.append("empty");
		} else {
			sb.append("[");
			for (int i = 0; i < list.size(); i++) {
				sb.append(list.get(i));
				if (i < list.size() - 1) {
					sb.append(", ");
				}
			}
			sb.append("]");
		}
		return sb.toString();
	}

}