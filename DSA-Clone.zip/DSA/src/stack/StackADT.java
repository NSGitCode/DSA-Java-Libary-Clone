package stack;

/** A LIFO List
 * @author sdb & Nicholas Sin
 */

public interface StackADT<E> {

    /** Put the given value on
     * top of this StackADT.
     * @return the value
     */

    E push(E value);

    /** @return value on top of this StackADT
     * Pre: This StackADT is not empty
     */
    E peek();

    /** Remove the top value of this StackADT
     * @return the value remove()
     * Pre: The StackADT is not empty
     */
    E pop();

    /** @return true iff this Stack is empty */
    boolean isEmpty();

    /** Clear the Stack */
    E clear();
}
