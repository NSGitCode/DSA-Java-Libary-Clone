package sort;
import list.*;


public class HeapSort<E extends Comparable> implements Sorter<E> {
    List<E> list;

    public void sort(List<E> list)
    {
        this.list = list;
        heapify(0);
        int last = list.size()-1;
        while(last > 0)
        {
            swap(0,last);
            last--;
            percDown(0,last);

        }
    }

    private void heapify(int root)
    {
        int max = list.size()-1;
        if(root >= max)
            return;
        heapify(2*root+2);
        heapify(2*root+1);
        percDown(root,max);
    }

    private void percDown(int root, int max)
    {
        int bc = biggerChild(root,max);
        while(root*2+1 <= max && greater(bc,root))
        {
            swap(root,bc);
            root = bc;
            bc = biggerChild(root,max);
        }
    }

    /** @return positon of root's biggerChild.
     * @param Don't go beyond max
     * Pre: root has at least one child.
     */
    private int biggerChild(int root, int max)
    {
        int left = 2*root+1, right = left+1;
        if(right > max)
            return left;
        if(greater(left,right))
            return left;
        return right;
    }

    /** @return true iff value at position x is
     * greater than the value of position y*/
    private boolean greater(int x, int y)
    {
        return list.get(x).compareTo(list.get(y)) > 0;
    }

    private void swap(int i, int j)
    {
        E temp = list.get(i);
        list.set(i, list.get(j));
        list.set(j,temp);
    }
}