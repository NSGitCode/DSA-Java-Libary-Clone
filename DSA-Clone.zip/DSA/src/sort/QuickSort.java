package sort;
import list.*;

/** QuickSort algorithm.
 * Use an ArrayList.
 * @author sdb & Nicholas Sin */

public class QuickSort <E extends Comparable> implements Sorter<E> { // avg case O(n log n), Worst case O(n^2)
    List<E> list;

    public void sort(List<E> list)
    {
        this.list = list;
        qSort(0, list.size()-1);
    }

    /** sort the portion of the list from start though end */
    private void qSort(int start, int end)
    {
        if (end - start < 1) //base case
        {
            return;
        }
        int p = partition(start,end);
        qSort(start, p-1); //sort left part
        qSort(p+1, end); //sort right part
    }

    /** Choose a value as a point, [start position] position p.
     * Post: All values to left of pivot are greater or equal to pivot.
     * @return Position of Pivot. */

    public int partition(int start, int end) {
        int mid = (start + end) / 2; // Choose the middle element as the pivot
        E pivot = list.get(mid);

        // Swap the pivot element with the last element to simplify the partitioning process
        swap(mid, end);

        int p = start;

        for (int i = start; i < end; i++) {
            if (list.get(i).compareTo(pivot) <= 0) {
                swap(i, p);
                p++;
            }
        }

        // Swap the pivot element back to its final position
        swap(p, end);

        return p;
    }

    private void swap(int i, int j)
    {
        E temp = list.get(i);
        list.set(i, list.get(j));
        list.set(j,temp);
    }


}
