package sort;
import list.*;

/** BubbleSort, applied to a LinkedList.
 * @author sdb & Nicholas Sin */

public class BubbleSortLinked<E extends Comparable> implements Sorter<E>{
    List<E> list;

    public void sort(List<E> list) //O(n^2)
    {
        this.list = list;

        E left, right;
        ListIterator<E> lit;

        for (int i = 0; i <list.size() -1; i++)
        {
            lit = list.listIterator();
            right = lit.next();
            for (int j = 0; j <list.size() -i -1; j++)
            {
                left = right;
                right = lit.next();
                if (left.compareTo(right) > 0) //swap?
                {
                    lit.remove();              //remove right member
                    lit.previous();            //back up
                    lit.add(right);            //add the removed value in correct spot
                    right = lit.next();        //prepare for next iteration
                    //no hidden loops
                }
            }
        }

    }



}
