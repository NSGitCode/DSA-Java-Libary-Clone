package sort;
import list.*;

/** Arrange the values in a List in increacing,
 * or decreacing order.
 * @author sdb & Nicholas Sin */

public interface Sorter<E extends Comparable> {
    /** sort the values in the given List */
    void sort (List<E> list);


}
